﻿Steps to install Wasteless 1.1 APK

Allow Installation from Unknown Sources.
1. Download the APK on your computer
2. On your android device, go to Settings>About>Software Information
3. Locate Build number. On some devices this option can be in More
4. Tap on Build number for 5-6 times and a toast message saying “You are now a developer will be displayed
5. Go back to your settings page and scroll at the bottom to find Developer options
6. Make sure USB debugging is checked
7. Make sure Verify apps over USB is unchecked
8. Go back to settings and inside Security, make sure Allow installation from Unknown Sources (in some devices just Unknown Sources) is checked

Install the .apk file.
9. Connect your android device to your computer
10. Copy the downloaded APK file to the phone
11. Go to that location in your phone using the devices File Manager
12. Find WasteLess and click the icon to install it
13. Wait for installation to be completed
14. In your main menu, find VirtualPantry and run it
15. You can now waste less with WasteLess ! Enjoy!